<?php

    # if this is your first time, you might need to check the directory 'Tutorial 1'  File first.
    // require 'config.php';
    header("Content-Type: application/json");

    $response = '{
        "ResultCode": 0, 
        "ResultDesc": "Confirmation Received Successfully"
    }';

    // Response from M-PESA Stream
    $mpesaResponse = file_get_contents('php://input');
    // $mpesaResponse = '{
    //     "TransactionType": "Pay Bill",
    //     "TransID": "SD93M8PEY5",
    //     "TransTime": "20240409110859",
    //     "TransAmount": "12.00",
    //     "BusinessShortCode": "4115729",
    //     "BillRefNumber": "0742753573",
    //     "InvoiceNumber": "",
    //     "OrgAccountBalance": "21566.00",
    //     "ThirdPartyTransID": "",
    //     "MSISDN": "2547 ***** 573",
    //     "FirstName": "JACKSON"
    // }';

    // log the response
    $logFile = "M_PESAConfirmationResponse.txt";

    $jsonMpesaResponse = json_decode($mpesaResponse, true); // We will then use this to save to database

    $transaction = array(
            ':TransactionType'      => $jsonMpesaResponse['TransactionType'],
            ':TransID'              => $jsonMpesaResponse['TransID'],
            ':TransTime'            => $jsonMpesaResponse['TransTime'],
            ':TransAmount'          => $jsonMpesaResponse['TransAmount'],
            ':BusinessShortCode'    => $jsonMpesaResponse['BusinessShortCode'],
            ':BillRefNumber'        => $jsonMpesaResponse['BillRefNumber'],
            ':InvoiceNumber'        => $jsonMpesaResponse['InvoiceNumber'],
            ':OrgAccountBalance'    => $jsonMpesaResponse['OrgAccountBalance'],
            ':ThirdPartyTransID'    => $jsonMpesaResponse['ThirdPartyTransID'],
            ':MSISDN'               => $jsonMpesaResponse['MSISDN'],
            ':FirstName'            => $jsonMpesaResponse['FirstName']
    );

    // write to file
    $log = fopen($logFile, "a");
    fwrite($log, $mpesaResponse);
    fclose($log);

    // echo $response;
    

    insert_response($transaction);
    
    function insert_response($jsonMpesaResponse)
{


    # 1.1. Config Section
    $dbName = 'macrmubo_gloha';
    $dbHost = 'localhost';
    $dbUser = 'macrmubo_jck';
    $dbPass = 'B5L&5p,JF=tr';

    # 1.1.1 establish a connection
    try {
        $con = new PDO("mysql:host=$dbHost;dbname=$dbName", $dbUser, $dbPass);
        // echo "Connection was successful";
    } catch (PDOException $e) {
        die("Error Connecting " . $e->getMessage());
    }

    # 1.1.2 Insert Response to Database
    try {
        $insert = $con->prepare("INSERT INTO `tbl_mpesa`(`mp_name`,`TransactionType`, `TransID`, `TransTime`, `TransAmount`, `ShortCode`, `BillRefNumber`, `InvoiceNumber`, `ThirdPartyTransID`, `MSISDN`) 
                                VALUES (:FirstName, :TransactionType, :TransID, :TransTime, :TransAmount, :BusinessShortCode, :BillRefNumber, :InvoiceNumber, :ThirdPartyTransID, :MSISDN)");


        // Bind parameters
        // var_dump($jsonMpesaResponse);
        $insert->bindParam(':FirstName', $jsonMpesaResponse[':FirstName']);
        $insert->bindParam(':TransactionType', $jsonMpesaResponse[':TransactionType']);
        $insert->bindParam(':TransID', $jsonMpesaResponse[':TransID']);
        $insert->bindParam(':TransTime', $jsonMpesaResponse[':TransTime']);
        $insert->bindParam(':TransAmount', $jsonMpesaResponse[':TransAmount']);
        $insert->bindParam(':BusinessShortCode', $jsonMpesaResponse[':BusinessShortCode']);
        $insert->bindParam(':BillRefNumber', $jsonMpesaResponse[':BillRefNumber']);
        $insert->bindParam(':InvoiceNumber', $jsonMpesaResponse[':InvoiceNumber']);
        $insert->bindParam(':ThirdPartyTransID', $jsonMpesaResponse[':ThirdPartyTransID']);
        $insert->bindParam(':MSISDN', $jsonMpesaResponse[':MSISDN']);
        

        // Execute the query
        $insert->execute();

        // Log the transaction to a file
        $Transaction = fopen('Transaction.txt', 'a');
        fwrite($Transaction, json_encode($jsonMpesaResponse));
        fclose($Transaction);
        insert_member($jsonMpesaResponse, $con);
        
        
    } catch (PDOException $e) {
        // Log the error
        $errLog = fopen('error.txt', 'a');
        fwrite($errLog, $e->getMessage());
        fclose($errLog);

        // Log the failed transaction
        $logFailedTransaction = fopen('failedTransaction.txt', 'a');
        fwrite($logFailedTransaction, json_encode($jsonMpesaResponse));
        fclose($logFailedTransaction);
    }
    
    $phone = substr($jsonMpesaResponse[':BillRefNumber'], -10);
    $name = $jsonMpesaResponse[':FirstName'];
    $amount = $jsonMpesaResponse[':TransAmount'];
    $sms = "Hi, $name \n We have received your payment of KES. $amount \n Regards \n Gloha Sacco Manager";
    // insert_member($jsonMpesaResponse, $con);
    sendsms($phone,$sms);
}

function sendsms($phone,$sms)
{
    $senderid="GlohaSacco";
        $apikey = '38109a2f91478e9a79b151c33746b438';
        $partnerid = 8899;

        if(!empty($sms) && !empty($phone)){
                $sms = urlencode($sms);
                $finalURL = "https://send.macrologicsys.com/api/services/sendsms/?apikey=$apikey&partnerID=$partnerid&message=$sms&shortcode=$senderid&mobile=$phone";
     // Initialize cURL session
        $ch = curl_init();

        // Set cURL options
        curl_setopt($ch, CURLOPT_URL, $finalURL);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

        // Execute the cURL request
        $response = curl_exec($ch);

        // Check for errors
        if ($response === FALSE) {
            // Error handling: Unable to send SMS
            echo "Failed to send SMS";
        } else {
            // Successful SMS sending
            // echo "SMS sent successfully";
        }

        curl_close( $ch );
        }
        
}

function insert_member($jsonMpesaResponse, $db)
{
  try{ 
    
    $reg = substr($jsonMpesaResponse[':BillRefNumber'],0,3);
    $name = $jsonMpesaResponse[':FirstName'];
    $amount = $jsonMpesaResponse[':TransAmount'];
    $phone = substr($jsonMpesaResponse[':BillRefNumber'], -10);
    $agentNumber = substr($jsonMpesaResponse[':BillRefNumber'], 3, 3); // Extract agent number
     
    if($reg == 'REG' || $reg == 'Reg' || $reg == 'reg'){
        
        $check = "SELECT * FROM tbl_members WHERE member_phone = $phone";
        $check_result = $db->query($check);
        $check_result->execute();
        $check_result->fetchAll();
        
        if($check_result->rowCount() < 1){
            // Assuming $db is your PDO database connection object
        $query = "INSERT INTO tbl_members (`member_name`, `fk_marital_id`, `member_residence`, `member_phone`, `member_number`, `member_spouse`, `member_beneficiaries`, `member_by`, `member_status`) VALUES (:member_name, 0, '', :member_phone, '', '', '[]', 1, 1)";
        
        // Prepare the statement
        $statement = $db->prepare($query);
        
        // Bind parameters
        $statement->bindParam(':member_name', $name);
        $statement->bindParam(':member_phone', $phone);
        
        
        // Execute the statement
        $result = $statement->execute();
        
            if ($result) {
                // Check if agent exists in the agents table
                $agentCheckQuery = "SELECT * FROM agents WHERE agent_no = :agent_number";
                $agentCheckStatement = $db->prepare($agentCheckQuery);
                $agentCheckStatement->bindParam(':agent_number', $agentNumber);
                $agentCheckStatement->execute();
                
                if ($agentCheckStatement->rowCount() > 0) {
                    
                    $agent = $agentCheckStatement->fetch(PDO::FETCH_ASSOC);
                    $agentId = $agent['id'];
                    
                    // Store commission data
                    $commissionQuery = "INSERT INTO commission (`agent_number`, `agent_id`, `amount`, `member_phone`) VALUES (:agent_number, :agent_id, :amount, :phone)";
                    $commissionStatement = $db->prepare($commissionQuery);
                    $commissionStatement->bindParam(':agent_number', $agentNumber);
                    $commissionStatement->bindParam(':agent_id', $agentId);
                    $commissionStatement->bindParam(':amount', $amount);
                    $commissionStatement->bindParam(':phone', $phone);
                    $commissionStatement->execute();

                    
                } else {
                    error_log("Agent with agent number $agentNumber does not exist.");
                }
                
                // Send welcome SMS
                $alpha_numeric = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
                $pass = substr(str_shuffle($alpha_numeric), 0, 8);
                $alpha = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
                $user = 'user'.substr(str_shuffle($alpha), 0, 4);
                $encpass = password_hash($pass, PASSWORD_BCRYPT);
                $role = 'member';
                $temp = 1;
                
                // Store auth data
                $authQuery = "INSERT INTO user (`name`, `mobile`, `password`, `role`, `temp`) VALUES (:name, :mobile, :password, :role, :temp)";
                $authStatement = $db->prepare($authQuery);
                $authStatement->bindParam(':name', $user);
                $authStatement->bindParam(':mobile', $phone);
                $authStatement->bindParam(':password', $encpass);
                $authStatement->bindParam(':role', $role);
                $authStatement->bindParam(':temp', $temp);
                $authStatement->execute();
                
                $msg = "Hi, $name \n Welcome to Gloha Sacco, we have received your payment of KES. $amount. Login to https://app.gloha-sacco.co.ke to view your transactions.\nUsername: $user\nPassword: $pass\n Regards \n Gloha Sacco Manager";
                sendsms($phone, $msg);
            } else {
                error_log("Failed to insert member into the database.");
            }
            
        } else {
                // Existing member logic
            }
       }
  } catch (PDOException $e) {
        // Log the error
        $errLog = fopen('error.txt', 'a');
        fwrite($errLog, $e->getMessage());
        fclose($errLog);

        // Log the failed transaction
        $logFailedTransaction = fopen('failedTransaction.txt', 'a');
        fwrite($logFailedTransaction, json_encode($jsonMpesaResponse));
        fclose($logFailedTransaction);
    }  

}

?>
