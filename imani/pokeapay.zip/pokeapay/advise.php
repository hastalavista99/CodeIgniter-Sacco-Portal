<?php

class TransactionHandler {
    private $pdo; // PDO connection
    private $request;

    public function __construct(PDO $pdo) {
        $this->pdo = $pdo;
        $this->request = json_decode(file_get_contents('php://input'), true);
    }

    public function advise() {
        // Check header status code
        $header = $this->request['header'];
        $code = $header['statusCode'];

        // File writing logic
        if ($code == "200") {
            // Prepare the full data for writing
            $fullData = [
                'header' => $header,
                'response' => $this->request['response']
            ];

            // Convert data to JSON for easy readability and parsing
            $jsonResponse = json_encode($fullData, JSON_PRETTY_PRINT);

            // Generate unique filename with timestamp
            $filePath = 'CO-OPresponse.txt';

            try {
                // Write the JSON response to the file
                if (file_put_contents($filePath, $jsonResponse) !== false) {
                    // Log successful file write
                    error_log('Transaction response successfully written to file: ' . $filePath);
                    
                    // Attempt to insert into database
                    $this->dbInsert($this->request['response']);
                    
                    return $this->sendJsonResponse([
                        'status' => 'success',
                        'message' => 'Transaction response saved successfully',
                        'file' => $filePath
                    ]);
                } else {
                    // Log file write failure
                    error_log('Failed to write transaction response to file');
                    
                    return $this->sendJsonResponse([
                        'status' => 'error',
                        'message' => 'Failed to save transaction response'
                    ], 500);
                }
            } catch (Exception $e) {
                // Log any exceptions during file writing
                error_log('Error writing transaction response: ' . $e->getMessage());
                
                return $this->sendJsonResponse([
                    'status' => 'error',
                    'message' => 'An error occurred while saving the transaction response'
                ], 500);
            }
        }

        // Handle non-200 status code scenario
        return $this->sendJsonResponse([
            'status' => 'error',
            'message' => 'Invalid status code'
        ], 400);
    }

    public function dbInsert($response) {
        try {
            // Prepare the insert statement
            $insert = $this->pdo->prepare("INSERT INTO `tbl_bank` (
                `transactionReferenceCode`, 
                `transactionDate`, 
                `transactionAmount`, 
                `accountNumber`, 
                `accountName`, 
                `institutionCode`, 
                `institutionName`
            ) VALUES (
                :transactionReferenceCode, 
                :transactionDate, 
                :transactionAmount, 
                :accountNumber, 
                :accountName, 
                :institutionCode, 
                :institutionName
            )");
            
            // Bind parameters
            $insert->bindParam(':transactionReferenceCode', $response['TransactionReferenceCode']);
            $insert->bindParam(':transactionDate', $response['TransactionDate']);
            $insert->bindParam(':transactionAmount', $response['TransactionAmount']);
            $insert->bindParam(':accountNumber', $response['AccountNumber']);
            $insert->bindParam(':accountName', $response['AccountName']);
            $insert->bindParam(':institutionCode', $response['InstitutionCode']);
            $insert->bindParam(':institutionName', $response['InstitutionName']);
            
            // Execute the statement
            $result = $insert->execute();

            if ($result) {
                error_log('Transaction successfully inserted into database');
                return true;
            } else {
                error_log('Failed to insert transaction into database');
                return false;
            }
        } catch (PDOException $e) {
            error_log('Database insertion error: ' . $e->getMessage());
            return false;
        }
    }

    // Helper method to send JSON response
    private function sendJsonResponse($data, $statusCode = 200) {
        http_response_code($statusCode);
        header('Content-Type: application/json');
        echo json_encode($data);
        exit;
    }
}

// Usage example
// Assuming you have a PDO connection established
try {
    $pdo = new PDO("mysql:host=localhost;dbname=macrmubo_gloha", "macrmubo_jck", "B5L&5p,JF=tr");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $handler = new TransactionHandler($pdo);
    $handler->advise();
} catch (PDOException $e) {
    error_log('Database connection error: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
}