<?php



function insert_response($jsonMpesaResponse){

    $dbName = 'enixpvcf_pay';
    $dbHost = 'localhost';
    $dbUser = 'enixpvcf_jck';
    $dbPass = 'Lw[,A&S?=gs+';
    
    

    try {
        // Establish database connection
        $con = new PDO("mysql:host=$dbHost;dbname=$dbName;charset=utf8mb4", $dbUser, $dbPass);
        $con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Prepare and execute SQL insert statement
        $insert = $con->prepare("INSERT INTO `tbl_mpesa` 
            (`mp_name`, `TransactionType`, `TransID`, `TransTime`, `TransAmount`, 
            `ShortCode`, `BillRefNumber`, `InvoiceNumber`, `ThirdPartyTransID`, `MSISDN`) 
            VALUES 
            (:mp_name, :TransactionType, :TransID, :TransTime, :TransAmount, 
            :ShortCode, :BillRefNumber, :InvoiceNumber, :ThirdPartyTransID, :MSISDN)");

        $insert->execute($jsonMpesaResponse);

        Log successful transactions (optional)
        $Transaction = fopen('Transaction.txt', 'a');
        fwrite($Transaction, json_encode($jsonMpesaResponse));
        fclose($Transaction);
        
        // echo "Transaction saved successfully";
    } catch(PDOException $e) {
        // Log error to file
        $errLog = fopen('error.txt', 'a');
        fwrite($errLog, $e->getMessage() . PHP_EOL);
        fclose($errLog);
        
        // Log failed transaction (optional)
        // $logFailedTransaction = fopen('failedTransaction.txt', 'a');
        // fwrite($logFailedTransaction, json_encode($jsonMpesaResponse));
        // fclose($logFailedTransaction);
        
        echo "An error occurred while processing the transaction";
    }
}
?>
