<!-- <nav class="d-block navbar p-3 text-bg-dark fixed-top w-100">
    <div class="container-fluid">
      <div class="d-flex flex-wrap align-items-center justify-content-between justify-content-lg-between">
        <a href="/" class="d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none display-6">
            <i class="bi-wallet2"></i> 
          Imaniline Sacco
        </a>

        
<div class="">
    <form class="col-12 col-lg-auto mb-3 mb-lg-0 me-lg-3" role="search">
          <input type="search" class="text-white form-control form-control-dark text-bg-dark" placeholder="Search..." aria-label="Search">
        </form>
</div>
        
        <div class="text-end">
          <button type="button" class="btn btn-outline-light me-2">Login</button>
        </div>
      </div>
    </div>
  </nav> -->